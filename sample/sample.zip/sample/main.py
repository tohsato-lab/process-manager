import time
import sys

print(sys.argv)
print("hello")
time.sleep(5)
print("finish")
