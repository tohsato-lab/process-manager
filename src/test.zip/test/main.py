import time

print('hello!!')
time.sleep(10)
print('world!!!!')
