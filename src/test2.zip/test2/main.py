import time

print('hello2!!')
time.sleep(5)
print('world2!!!!')
